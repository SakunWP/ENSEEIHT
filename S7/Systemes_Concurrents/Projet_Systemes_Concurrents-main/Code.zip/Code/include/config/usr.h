/*----------------------------------------------------------------------------*/
/* Est-ce que l'on incorpore le monde utilisateur ?                           */
/*----------------------------------------------------------------------------*/
#define MANUX_USR

/**
 * @brief le nom du fichier contenant le init de usr
 */
#ifndef MANUX_USR_INIT
#   define MANUX_USR_INIT init.o
#endif
