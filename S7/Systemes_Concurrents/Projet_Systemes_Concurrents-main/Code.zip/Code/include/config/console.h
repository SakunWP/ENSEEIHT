/**
 * Utilise-t-on la console ?
 */
#define MANUX_CONSOLE

/*
 * Le numéro majeur des consoles
 */
#define MANUX_CONSOLE_MAJEUR  0

/**
 * @brief protège-t-on les accès aux consoles ?
 */
//#define MANUX_CONSOLE_AVEC_MUTEX
