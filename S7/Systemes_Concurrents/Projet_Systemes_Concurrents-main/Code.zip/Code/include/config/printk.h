/*
 * Implantation de printk
 */
#define MANUX_PRINTK

