/**
 * Quelle configuration des outils de synchronisation 
 */

/**
 * @brief Ajout de structures et fonctions permettant d'observer l'état
 * des outils de synchronisation 
 */

#define MANUX_ATOMIQUE_AUDIT
