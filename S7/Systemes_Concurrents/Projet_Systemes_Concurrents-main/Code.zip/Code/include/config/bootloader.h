/*----------------------------------------------------------------------------*/
/* Utilisation dans le noyau, d'outils de communication avec le bootloader.   */
/*----------------------------------------------------------------------------*/
#define MANUX_BOOTLOADER

