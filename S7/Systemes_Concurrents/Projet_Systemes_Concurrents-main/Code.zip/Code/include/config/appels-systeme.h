/**
 * Définition des appels système
 */
#define MANUX_APPELS_SYSTEME

/**
 * @brief Mesure de statistiques d'utilisation par les tâches
 */
#define MANUX_AS_AUDIT
