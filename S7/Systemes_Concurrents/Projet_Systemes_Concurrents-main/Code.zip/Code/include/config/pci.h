/*----------------------------------------------------------------------------*/
/*   Prise en compte du bus PCI.                                              */
/*----------------------------------------------------------------------------*/
#define MANUX_PCI

/*
 * Pour le moment, on ne cherche qu'un bus, donc aucun risque d'avoir plus de 
 * 32 équipements.
 */
#define MANUX_NB_MAX_EQUIPEMENTS_PCI 32

