/*----------------------------------------------------------------------------*/
/*      Gestion des situations désespérées, ...                               */
/*                                                                            */
/*                                                  (C) Manu Chaput 2000-2021 */
/*----------------------------------------------------------------------------*/
#include <manux/panique.h>

/*
 * Soyons clairs, il n'y a plus rien à gérer si on en arrive là !
 * Juste afficher ce que l'on peut, en utilisant le moins de services
 * externes possible ...
 */
void paniqueNoyau()
{
}
